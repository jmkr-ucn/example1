/*
 * File:   light_led.c
 * Author: jmk
 *
 * Created on 27. november 2013, 01:46
 */

#include <p18cxxx.h>
#include <timers.h>
//----------------Start of configuration------------------------------
#include <p18F67J60.h>
// CONFIG1L
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on SWDTEN bit))
#pragma config STVR = OFF        // Stack Overflow/Underflow Reset Enable bit (Reset on stack overflow/underflow enabled)
#pragma config XINST = OFF     // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG1H
#pragma config CP0 = OFF        // Code Protection bit (Program memory is not code-protected)

// CONFIG2L
#pragma config FOSC = ECPLL     // Oscillator Selection bits (EC oscillator, PLL enabled and under software control, CLKO function on OSC2)
#pragma config FOSC2 = ON       // Default/Reset System Clock Select bit (Clock selected by FOSC1:FOSC0 as system clock is enabled when OSCCON<1:0> = 00)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable (Fail-Safe Clock Monitor enabled)
#pragma config IESO = OFF       // Two-Speed Start-up (Internal/External Oscillator Switchover) Control bit (Two-Speed Start-up enabled)

// CONFIG2H
#pragma config WDTPS = 32768    // Watchdog Timer Postscaler Select bits (1:32768)

// CONFIG3L

// CONFIG3H
#pragma config ETHLED = OFF      // Ethernet LED Enable bit (RA0/RA1 are multiplexed with LEDA/LEDB when Ethernet module is enabled and function as I/O when Ethernet is disabled)
//----------------------------------------end of configuration------------------------
void hw_initialize(void);
unsigned char buttonRead(void);
void delay(void);
void timer_isr(void);


/*
 * For PIC18xxxx devices, the low interrupt vector is found at 000000018h.
 * Change the default code section to the absolute code section named
 * low_vector located at address 0x18.
 */
#pragma code low_vector=0x18

void low_interrupt(void) {
    /*
     * Inline assembly that will jump to the ISR.
     */
    _asm GOTO timer_isr _endasm
}

/*
 * Returns the compiler to the default code section.
 */
#pragma code

/*
 * Specifies the function timer_isr as a low-priority interrupt service
 * routine. This is required in order for the compiler to generate a
 * RETFIE instruction instead of a RETURN instruction for the timer_isr
 * function.
 */
#pragma interruptlow timer_isr

/*
 * Define the timer_isr function. Notice that it does not take any
 * parameters, and does not return anything (as required by ISRs).
 */
void timer_isr(void) {
    /*
     * Clears the TMR0 interrupt flag to stop the program from processing the
     * same interrupt multiple times.
     */
    INTCONbits.TMR0IF = 0;

    LATEbits.LATE0 = !LATEbits.LATE0; // Toggle LED
    //LATEbits.LATE0 = 1;
}
//#pragma code main = 0x15f2e // Hmmm simpelt men ikke s� korrekt
void main(void) {

    hw_initialize(); //Initialize ports on microcontroller
    LATBbits.LATB3 = 1;
    LATEbits.LATE0 = 0;
/*
     * Enable global interrupts.
     */
    INTCONbits.GIE = 1;
    INTCONbits.GIEL = 1;
    INTCON2bits.TMR0IP = 0; //Set priority
    RCONbits.IPEN = 1; // Enable interrupt priorities
    
    /*
     * Enable the TMR0 interrupt, setting up the timer as an internal
     * 16-bit clock.
     */
    OpenTimer0(TIMER_INT_ON & T0_SOURCE_INT & T0_8BIT & T0_PS_1_2 );
    
    
    while (1) {
    };

    return;
}

void hw_initialize() {
    INTCON = 0; // Disable all interrupt sources
    PIE1 = 0;
    PIE2 = 0;
    PIE3 = 0;
    // for "TRISx" registers '0'=out and '1'=in, determines if port should be input or output
    //TRISA = 0x28; //0b0010 1000
    //LATA = 0x08; //0b0000 1000
    TRISB = 0x37; //0b0011 0111
    //LATB = 0xc0; //0b1100 0000
    //TRISC = 0xff; //0b1111 1111 -bit0 is the user button
    //LATC = 0x01; //0b0000 0001
    //TRISD = 0x06; //0b0000 0110
    //LATD = 0x00; //0b0000 0000
    TRISE = 0x30; //0b0011 0000 -bit0 is the LED
    LATE = 0x00; //0b0000 0000
    //TRISF = 0x7e; //0b0111 1110
    //LATF = 0x00; //0b0000 0000
    //TRISG = 0x10; //0b0001 0000
    //LATG = 0x00; //0b0000 0000


}

unsigned char buttonRead(void) {
    return PORTCbits.RC0; // same pin for all hardware versions
}

void delay(void) {

}